from typing import Dict, List
from uuid import UUID, uuid4
from pydantic import BaseModel, Field


class Node(BaseModel):
    id: UUID | str = Field(default_factory=uuid4)
    type: str
    name: str
    attributes: Dict[str, str] = Field(default_factory=dict)


class Edge(BaseModel):
    source: str
    target: str
    type: str
    name: str
    attributes: Dict[str, str] = Field(default_factory=dict)

class Triples(BaseModel):
    source_entity: Node
    target_entity: Node
    edge: Edge


class KG(BaseModel):
    nodes: List[Node]
    edges: List[Edge]

