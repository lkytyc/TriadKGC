class KGException(Exception):
    """Base exception for Knowledge Graph operations"""
    pass


class NodeNotFoundException(KGException):
    """Node not found"""
    def __init__(self, node_id: str):
        super().__init__(f"Node not found: {node_id}")


class EdgeNotFoundException(KGException):
    """Edge not found"""
    def __init__(self, source_id: str, target_id: str):
        super().__init__(f"Edge not found: source={source_id}, target={target_id}")


class NodeAlreadyExistsException(KGException):
    """Attempt to create a duplicate node"""
    def __init__(self, node_name: str):
        super().__init__(f"Node already exists: {node_name}")


class InvalidEdgeReferenceException(KGException):
    """Edge source or target refers to a non-existent node"""
    def __init__(self, missing_node_id: str):
        super().__init__(f"Edge references a non-existent node ID: {missing_node_id}")


class KGLoadException(KGException):
    """Exception occurred while loading KG from dict or JSON"""
    def __init__(self, detail: str):
        super().__init__(f"Failed to load KG: {detail}")
