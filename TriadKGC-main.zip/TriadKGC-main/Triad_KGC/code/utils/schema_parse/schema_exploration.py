import re
import asyncio
import json

from Triad_KGC.code.kg_verification.retrieve.related_retrieve import cosine_similarity
from Triad_KGC.code.schema_exploration.related_retrieve import batch_get_vectors


def transform_dict(original_dict):
    """
    Normalize the definition dictionary to handle inconsistent LLM output formats

    Args:
        original_dict: Dictionary with potentially inconsistent format from LLM

    Returns:
        Normalized dictionary with consistent structure
    """
    new_dict = {}

    for key, value in original_dict.items():
        if isinstance(value, str):
            # Split value using regex to handle newlines and whitespace
            sub_items = re.split(r'\n\s+', value.strip())
            for item in sub_items:
                if ':' in item:
                    # Split each sub-item and its explanation
                    sub_key, sub_value = item.split(':', 1)
                    new_dict[sub_key.strip()] = sub_value.strip()
                else:
                    # If no colon, add original value directly
                    new_dict[key] = item.strip()
        else:
            new_dict[key] = value

    return new_dict


def extract_definition(response):
    """
    Extract definitions from response text without relying on identifiers

    Args:
        response: Raw text response containing definitions

    Returns:
        Dictionary of extracted definitions
    """
    definitions_text = response.strip()
    definition = {}

    # Process each line in the response
    for line in definitions_text.split('\n'):
        line = line.strip()
        # Skip empty lines
        if not line:
            continue
        # Process lines in key: value format
        if ':' in line:
            key_part, value_part = line.split(':', 1)
            key = key_part.strip()
            value = value_part.strip()
            # Add to dictionary if key doesn't exist
            if key not in definition:
                definition[key] = value
    # Return normalized definition dictionary
    return transform_dict(definition)


def get_new_entity_types_from_response(response):
    """
    Extract entity types and their instances from LLM response

    Args:
        response: Raw text response containing entity classifications

    Returns:
        Dictionary mapping entity types to their instances
    """
    try:
        entity_type_dict = {}

        # Process each line in the response
        for line in response.split('\n'):
            line = line.strip()
            if not line:
                continue

            # Split entity type and entity list
            if ':' in line:
                type, entities_str = line.split(':', 1)
                type = type.strip().strip("*")

                # Extract entity instances
                entities = [e.strip(' "') for e in entities_str.split(',')]
                entities = [e for e in entities if e]  # Remove empty entities

                # Add to dictionary
                entity_type_dict[type] = entities

    except Exception as e:
        print("Error processing entities: ", e)
        raise
    return entity_type_dict


def get_new_relationship_types_from_response(response):
    """
    Extract relationship types and their instances from LLM response

    Args:
        response: Raw text response containing relationship classifications

    Returns:
        Dictionary mapping relationship types to their instances
    """
    try:
        relation_type_dict = {}

        # Process each line in the response
        for line in response.split('\n'):
            line = line.strip()
            if not line:
                continue

            # Split relationship type and relationship list
            if ':' in line:
                type, relationships_str = line.split(':', 1)
                type = type.strip()

                # Extract relationship instances
                relationships = [rel.strip(' "') for rel in relationships_str.split(',')]
                relationships = [rel for rel in relationships if rel]  # Remove empty relationships

                # Add to dictionary
                relation_type_dict[type] = relationships

    except Exception as e:
        print("get_new_relationship_categories Error: ", e)
        raise  # Re-raise the caught exception

    return relation_type_dict


def convert_to_type_triples(instance_triples, entity_type_dict, relation_type_dict):
    """
    Convert instance triples to type triples with case-insensitive matching and deduplication

    Args:
        instance_triples: List of instance triples
        entity_type_dict: Dictionary mapping entity types to their instances
        relation_type_dict: Dictionary mapping relation types to their instances

    Returns:
        List of deduplicated type triples
    """
    try:
        def find_entity_type(entity_name):
            """Find entity type for given entity name (case-insensitive)"""
            target_lower = entity_name.lower()
            for entity_type, entities in entity_type_dict.items():
                # Compare lowercase versions
                if any(entity.lower() == target_lower for entity in entities):
                    return entity_type
            return None

        def find_relation_type(relation_name):
            """Find relation type for given relation name (case-insensitive with space handling)"""
            # Normalize relation name: trim + collapse spaces + lowercase
            normalized_relation = " ".join(relation_name.strip().split()).lower()
            for relation_type, relations in relation_type_dict.items():
                # Compare normalized versions
                if any(" ".join(rel.strip().split()).lower() == normalized_relation for rel in relations):
                    return relation_type
            return None

        typed_triples = []
        seen_triples = set()  # For deduplication

        for triple in instance_triples:
            head_type = find_entity_type(triple['head'])
            tail_type = find_entity_type(triple['tail'])
            relation_type = find_relation_type(triple['relation'])

            if head_type and tail_type and relation_type:
                # Create deduplication key (case-insensitive with normalized spaces)
                triple_key = (
                    head_type, triple['head'].lower(),
                    relation_type, " ".join(triple['relation'].strip().split()).lower(),
                    tail_type, triple['tail'].lower()
                )
                if triple_key not in seen_triples:
                    seen_triples.add(triple_key)
                    typed_triple = {
                        'DirectionalEntity': {'type': head_type, 'name': triple['head']},
                        'Relation': {'type': relation_type, 'name': triple['relation'].strip()},
                        'DirectedEntity': {'type': tail_type, 'name': triple['tail']}
                    }
                    typed_triples.append(typed_triple)

        return typed_triples

    except Exception as e:
        print(f"Error in convert_to_type_triples: {e}")
        raise

def convert_to_type_triples_without_type_triples(instance_triples, entity_type_dict):
    """
            Convert instance triples to type triples with case-insensitive matching and deduplication

            Args:
                instance_triples: List of instance triples
                entity_type_dict: Entity type dictionary {type: [entity list]}

            Returns:
                List of deduplicated type triples
            """
    try:
        def find_entity_type(entity_name):
            """Find entity type for given entity name (completely case-insensitive)"""
            target_lower = entity_name.lower()
            for entity_type, entities in entity_type_dict.items():
                if any(entity.lower() == target_lower for entity in entities):
                    return entity_type
            return None

        typed_triples = []
        seen_triples = set()  # Set for deduplication

        for triple in instance_triples:
            head_type = find_entity_type(triple['head'])
            tail_type = find_entity_type(triple['tail'])
            relation_name = triple['relation'].strip()  # Use relation name directly as type

            if head_type and tail_type:
                # Create deduplication key (based on types and names, case and space insensitive)
                triple_key = (
                    head_type, triple['head'].lower(),
                    relation_name.lower(),  # Relation name participates in deduplication as type
                    tail_type, triple['tail'].lower()
                )
                if triple_key not in seen_triples:
                    seen_triples.add(triple_key)
                    typed_triple = {
                        'DirectionalEntity': {'type': head_type, 'name': triple['head']},
                        'Relation': {'type': relation_name, 'name': relation_name},  # Type and name are same
                        'DirectedEntity': {'type': tail_type, 'name': triple['tail']}
                    }
                    typed_triples.append(typed_triple)

        return typed_triples

    except Exception as e:
        print(f"Error in convert_to_type_triples: {e}")
        raise


def extract_unique_entities_and_relations(triples):
    """
    Extract unique entities and relations from a list of triples

    Args:
        triples: List of triples to process

    Returns:
        Dictionary containing sorted lists of unique entities and relations
    """
    entities = set()
    relations = set()

    for item in triples:
        # Add head and tail entities
        entities.add(item["head"])
        entities.add(item["tail"])
        # Add relation (with whitespace trimmed)
        relations.add(item["relation"].strip())

    return {
        "entities": sorted(list(entities)),
        "relations": sorted(list(relations))
    }

async def merge_type_dicts_with_semantic(dict1, dict2):
    """
    Merge two type dictionaries using semantic similarity between keys

    Args:
        dict1: First dictionary to merge (will be used as base)
        dict2: Second dictionary to merge

    Returns:
        Merged dictionary with duplicate values removed
    """
    # Collect all words that need vector representations
    all_words = list(dict1.keys()) + list(dict2.keys())

    # Batch get vector representations for all words to minimize API calls
    word_vectors = await batch_get_vectors(all_words)

    # Pre-compute vectors for dict1 keys
    dict1_vectors = {k: word_vectors[k] for k in dict1.keys()}

    # Initialize result dictionary with dict1 contents
    merged = dict1.copy()
    unmatched_keys = set(dict2.keys())  # Track keys from dict2 that haven't been matched

    # Process each key from dict2 concurrently with rate limiting
    semaphore = asyncio.Semaphore(100)  # Limit concurrent operations

    async def process_item(key2, values2):
        async with semaphore:
            # Find most similar key in dict1
            max_similarity = 0
            best_match = None

            # Calculate similarity between key2 and each key in dict1
            for key1, vec1 in dict1_vectors.items():
                vec2 = word_vectors[key2]
                similarity = cosine_similarity(vec1, vec2)

                if similarity > max_similarity:
                    max_similarity = similarity
                    best_match = key1

            # Only consider matches with similarity > 0.7
            if max_similarity > 0.7:
                unmatched_keys.discard(key2)
                return best_match, values2, None
            else:
                return None, None, (key2, values2)

    # Create processing tasks for all items in dict2
    tasks = [process_item(k, v) for k, v in dict2.items()]

    # Process results as they complete
    for coro in asyncio.as_completed(tasks):
        best_match, values_to_merge, new_item = await coro

        if best_match:
            # Merge values into existing key from dict1
            merged[best_match].extend(values_to_merge)
        elif new_item:
            # Add new key-value pair to merged dictionary
            key, values = new_item
            merged[key] = values.copy()

    # Remove duplicate values from merged dictionary
    return {k: list(set(v)) for k, v in merged.items()}


def delete_irrelevant_definitions(kg_schema, definition_dict):
    """
    Filter definitions dictionary to only include types that exist in the knowledge graph schema

    Args:
        kg_schema: JSON string representing the knowledge graph schema
        definition_dict: Dictionary of type definitions to filter

    Returns:
        Filtered dictionary containing only relevant definitions
    """
    # Parse the JSON schema into a Python dictionary
    schema_data = json.loads(kg_schema)
    relevant_definitions = {}

    # Collect all node and edge types from the schema
    existing_types = set()

    # Extract node types
    for node in schema_data["nodes"]:
        existing_types.add(node["type"])

    # Extract edge/relationship types
    for edge in schema_data["edges"]:
        existing_types.add(edge["type"])

    # Only keep definitions for types that exist in the schema
    for type_name, type_definition in definition_dict.items():
        if type_name in existing_types:
            relevant_definitions[type_name] = type_definition

    return relevant_definitions

def add_relationship_definition(definition):
    """Because there are only a few relationships in this dataset,
    the experiment did not generate relationship types for WN18RR dataset.
    Instead, each relationship was directly treated as a relationship type, and this function provides a definition for each relationship"""
    definition.update(
        {
            "member of domain usage": "The member of domain usage relation connects a word sense (synset) to the technical or professional domain in which it is most commonly used. This relation captures the pragmatic or terminological context of a term rather than its structural or hierarchical classification. For example, a medical drug, legal concept, or computing term might be linked to domains such as “medicine,” “law,” or “computer science.” In triple completion tasks, when this relation appears, the missing entity should be the technical category or usage domain that the head entity belongs to—typically a concept like medical_term_NN_1, legal_term_NN_1, or computer_term_NN_1. Care must be taken not to confuse this with hypernym relations or functional components; only domain-specific classification terms should be used.",
            "verb group": "The verb group relation connects verb senses that are semantically related and often interchangeable in usage. It is used to group verbs that perform similar actions or belong to the same category of behavior, such as \"buy\" and \"purchase\" or \"run\" and \"sprint.\" While these verbs may not be perfect synonyms, they typically share core semantic features and can often substitute for each other in certain contexts. In triple completion, this relation requires identifying a verb sense that represents a closely related action, with high overlap in meaning and usage with the source verb. It is important to preserve the same part of speech and action type, and to avoid selecting hypernyms or causally related verbs that do not belong to the same action family.",
            "member of domain region": "The member of domain region relation links a word sense to a geographic, cultural, or regional context where that concept is specifically used or culturally rooted. It captures the regional or national relevance of a term, rather than its general meaning. This is useful for concepts that are uniquely tied to specific countries, cultures, or dialects—for example, a traditional food, regional instrument, or administrative system. In triple completion tasks, this relation should be completed with the specific geographic or cultural synset (e.g., bavaria_NN_1, china_NN_1, us_NN_1) that the concept is associated with. Avoid abstract or non-regional categories, and do not substitute usage domains or functional descriptions for geographic entities.",
            "member meronym": "The member meronym relation connects a concept to a larger collection or group that it is a member of. Unlike part-whole relations that denote physical components, member meronym specifically captures the idea of membership within a collective entity, such as an individual being part of a population or a species belonging to a taxonomic group. For example, “soldier” is a member of an “army,” and “oak” is a member of a “forest.” In triple completion, when this relation is used, the head entity should represent an individual unit, while the tail entity should denote a collective grouping. It is important to avoid confusing this with structural part-whole relations (has part) or class-subclass hierarchies (hypernym). The target should be a noun sense representing a defined group or set.",
            "hypernym": "The hypernym relation connects a more specific concept (hyponym) to a more general or abstract class it belongs to (hypernym). It represents a classical is-a relationship, such as “dog” is a hypernym of “poodle,” or “tool” is a hypernym of “hammer.” In the WordNet ontology, this relation forms the backbone of the taxonomic hierarchy, allowing concepts to be generalized up a semantic tree. For triple completion, the head entity should be a more specific noun or verb sense, while the tail entity must be its immediate superclass—a broader category under which the head clearly falls. The chosen hypernym must preserve the part of speech and WordNet sense granularity (e.g., modify_VB_3 instead of just modify). Do not generalize too far up the hierarchy or use approximate synonyms.",
            "has part": "The has part relation links an entity to another entity that forms a functional or physical component of it. This relation is the inverse of part meronym and describes how something is composed of its parts. For example, a “car” has part “engine,” or a “tree” has part “leaf.” In triple completion, the head entity represents a whole, while the tail entity must represent a semantic component or substructure that typically exists within it. The parts should be semantically essential or typical, rather than merely incidental. Care should be taken not to confuse this with member meronym (group membership) or has instance (class-instance). The completion should result in a part-whole relation grounded in real-world or conceptual structure.",
            "derivationally related form": "The derivationally related form relation links two synsets that share the same root word but differ in part of speech or grammatical role due to derivational morphology. It captures morphological transformations, such as from verb to noun or adjective to adverb, where the core meaning is preserved but grammatical function changes. Examples include “decide” (verb) and “decision” (noun), or “clarify” (verb) and “clarity” (noun). In triple completion, this relation should connect a word sense to another with a shared lexical root and clearly derivational connection, not merely a semantic similarity. The parts of speech must differ, and both entities must be existing, sense-level entries in WordNet (e.g., clarify_VB_2 → clarity_NN_1). Avoid filling with synonyms, paraphrases, or loosely connected forms.",
            "also see": "The also see relation links two synsets that are not strictly semantically equivalent but are closely related in meaning or usage. This relation is often used to suggest associated concepts that may occur in similar contexts or that are worth comparing. Unlike synonymy or taxonomic hierarchy, this connection is associative and lateral—it points to conceptual neighbors, not parents or parts. For example, \"teacher\" and \"educator\" might be linked via also see, even if their definitions are not identical. In triple completion, this relation should be filled with synsets that are topically or functionally connected, while avoiding hypernyms, derivational forms, or unrelated concepts. Candidates should be selected based on meaningful contextual similarity, often appearing in the same lexical neighborhood in WordNet.",
            "instance hypernym": "The instance hypernym relation links a proper noun or named entity to the class or category it is an instance of, essentially forming an is-instance-of relationship. Unlike the regular hypernym relation, which connects types to supertypes, instance hypernym deals specifically with individual entities (cities, people, countries, organizations) and their semantic categories. For example, “Einstein” is an instance of “physicist,” and “Mombasa” is an instance of “urban center.” In triple completion, the head entity is a named, concrete entity (e.g., leyden_NN_1, nagoya_NN_1), while the tail must be a general class (e.g., urban_center_NN_1, scientist_NN_1) that exists as a synset in WordNet. Care must be taken not to substitute the tail with paraphrases or general descriptions; it must be a precise, predefined category.",
            "synset domain topic of": "The synset domain topic of relation connects a word sense to the semantic domain or thematic area it is most associated with. It reflects conceptual categorization, indicating that a given word or concept is typically discussed within a broader topic such as “military,” “physics,” or “religion.” For example, “army_officer” is linked to “military_science.” This relation helps WordNet organize concepts by domain, providing higher-level structure beyond hierarchical types. In triple completion, the tail entity must be a domain label synset (e.g., war_machine_NN_1, medical_science_NN_1) that represents a topic, not a hypernym or part. Ensure that the domain is semantically relevant to the head and exists in WordNet’s inventory of domain topic synsets.",
            "similar to": "The similar to relation connects adjective synsets that are semantically similar but not strictly synonymous. It is used to link adjectives that share closely aligned meaning, often with subtle distinctions in tone, usage, or specificity. For instance, “fearful” may be similar to “afraid,” or “happy” to “joyful,” even if they are not interchangeable in all contexts. This relation plays a key role in the adjective ontology in WordNet, which lacks the strict taxonomic structure seen in nouns. In triple completion, the relation should be used to suggest a closely related adjective synset, ensuring that both entities belong to the adjective part of speech and reflect nearly equivalent descriptive meaning. Avoid including synonyms, antonyms, or unrelated modifiers."
        }
    )
    return definition