import asyncio
from copy import deepcopy
from typing import Optional, Dict, List
from uuid import uuid4
from asyncio import Lock
from pydantic import ValidationError
from Triad_KGC.code.types.models import Node, Edge, KG
from Triad_KGC.code.types.exceptions import (
    NodeNotFoundException,
    EdgeNotFoundException,
    InvalidEdgeReferenceException,
    KGLoadException,
)


class KGOperator:
    def __init__(self, kg: Optional[KG] = None):
        self.kg = kg if kg else KG(nodes=[], edges=[])
        self._lock = Lock()

    # ---------- Internal helper methods (no lock required) ----------
    def _find_node_by_id(self, node_id: str) -> Optional[Node]:
        return next((n for n in self.kg.nodes if str(n.id) == str(node_id)), None)

    def _find_edges_by_source(self, source_id: str) -> List[Edge]:
        return [e for e in self.kg.edges if e.source == str(source_id)]

    def _find_edges_by_target(self, target_id: str) -> List[Edge]:
        return [e for e in self.kg.edges if e.target == str(target_id)]

    def _find_node_by_name(self, name: str) -> Optional[Node]:
        return next((n for n in self.kg.nodes if n.name == name), None)

    def _find_edge_by_source_target(self, source_id: str, target_id: str) -> Optional[Edge]:
        return next((e for e in self.kg.edges if e.source == str(source_id) and e.target == str(target_id)), None)

    # ---------- Public asynchronous methods ----------
    async def create_node(self, type_: str, name: str, attributes: Optional[Dict[str, str]] = None) -> Node:
        async with self._lock:
            node = Node(id=uuid4(), type=type_, name=name, attributes=attributes or {})
            self.kg.nodes.append(node)
            return node

    async def create_edge(self, source_id: str, target_id: str, type_: str, name: str,
                          attributes: Optional[Dict[str, str]] = None) -> Edge:
        async with self._lock:
            if not self._find_node_by_id(source_id):
                raise InvalidEdgeReferenceException(source_id)
            if not self._find_node_by_id(target_id):
                raise InvalidEdgeReferenceException(target_id)
            edge = Edge(source=source_id, target=target_id, type=type_, name=name, attributes=attributes or {})
            self.kg.edges.append(edge)
            return edge

    async def find_node_by_id(self, node_id: str) -> Optional[Node]:
        async with self._lock:
            return self._find_node_by_id(node_id)

    async def find_edges_by_source(self, source_id: str) -> List[Edge]:
        async with self._lock:
            return self._find_edges_by_source(source_id)

    async def find_edges_by_target(self, target_id: str) -> List[Edge]:
        async with self._lock:
            return self._find_edges_by_target(target_id)

    async def find_node_by_name(self, name: str) -> Optional[Node]:
        async with self._lock:
            return self._find_node_by_name(name)

    async def find_nodes_by_type(self, type_: str) -> List[Node]:
        async with self._lock:
            return [node for node in self.kg.nodes if node.type == type_]

    async def find_triple_by_one_node_and_one_edge(self, node_name: str, edge_name: str) -> List[Edge]:
        """
        Find triples by node name and edge name.
        :param node_name: name of the node
        :param edge_name: name or type of the edge
        :return: List[Edge] matching triples
        """
        async with self._lock:
            result = []
            for edge in self.kg.edges:
                if edge.name == edge_name or edge.type == edge_name:
                    source_node = self._find_node_by_id(edge.source)
                    target_node = self._find_node_by_id(edge.target)
                    if source_node and source_node.name == node_name:
                        result.append(edge)
                    elif target_node and target_node.name == node_name:
                        result.append(edge)
            return result

    async def find_edge_by_source_target(self, source_id: str, target_id: str) -> Optional[Edge]:
        async with self._lock:
            return self._find_edge_by_source_target(source_id, target_id)

    async def update_node(self, node_id: str, name: Optional[str] = None,
                          attributes: Optional[Dict[str, str]] = None) -> bool:
        async with self._lock:
            node = self._find_node_by_id(node_id)
            if not node:
                raise NodeNotFoundException(node_id)
            if name is not None:
                node.name = name
            if attributes:
                node.attributes.update(attributes)
            return True

    async def update_edge(self, source_id: str, target_id: str, name: Optional[str] = None,
                          attributes: Optional[Dict[str, str]] = None) -> bool:
        async with self._lock:
            for edge in self.kg.edges:
                if edge.source == source_id and edge.target == target_id:
                    if name is not None:
                        edge.name = name
                    if attributes:
                        edge.attributes.update(attributes)
                    return True
            raise EdgeNotFoundException(source_id, target_id)

    async def delete_node(self, node_id: str) -> bool:
        async with self._lock:
            node = self._find_node_by_id(node_id)
            if not node:
                raise NodeNotFoundException(node_id)
            self.kg.nodes.remove(node)
            self.kg.edges = [e for e in self.kg.edges if e.source != node_id and e.target != node_id]
            return True

    async def delete_edge(self, source_id: str, target_id: str) -> bool:
        async with self._lock:
            found = False
            new_edges = []
            for e in self.kg.edges:
                if e.source == source_id and e.target == target_id:
                    found = True
                    continue
                new_edges.append(e)
            if not found:
                raise EdgeNotFoundException(source_id, target_id)
            self.kg.edges = new_edges
            return True

    async def to_dict(self) -> Dict:
        async with self._lock:
            return self.kg.model_dump()

    async def to_json(self) -> str:
        async with self._lock:
            return self.kg.model_dump_json(indent=4)

    # ---------- Class methods ----------
    @classmethod
    async def from_dict(cls, data: Dict) -> "KGOperator":
        try:
            kg = KG(**data)
            return cls(kg)
        except Exception as e:
            raise KGLoadException(str(e))

    @classmethod
    async def from_json(cls, json_str: str) -> "KGOperator":
        from pydantic import TypeAdapter
        adapter = TypeAdapter(KG)
        try:
            kg = adapter.validate_json(json_str)
            return cls(kg)
        except ValidationError as e:
            raise KGLoadException(str(e))

    async def merge_kg_list(self, kg_list: List[KG]) -> None:
        """
        Merge multiple KGs into the current KG managed by this operator, avoiding duplicate nodes and invalid edges.
        :param kg_list: List[KG] to be merged
        """
        async with self._lock:
            existing_node_ids = {str(node.id) for node in self.kg.nodes}

            for kg in kg_list:
                for node in kg.nodes:
                    node_id_str = str(node.id)
                    if node_id_str in existing_node_ids:
                        continue
                    self.kg.nodes.append(deepcopy(node))
                    existing_node_ids.add(node_id_str)

                valid_node_ids = {str(n.id) for n in self.kg.nodes}
                for edge in kg.edges:
                    if edge.source in valid_node_ids and edge.target in valid_node_ids:
                        self.kg.edges.append(deepcopy(edge))

    @staticmethod
    async def merge_kg_list_return(kg_list: List[KG]) -> KG:
        """
        Merge multiple KGs into a new KG object. Only ensures ID uniqueness;
        nodes with the same name/type are allowed to coexist.
        """
        if not kg_list:
            return KG(nodes=[], edges=[])

        new_nodes = []
        new_edges = []
        existing_node_ids = set()

        for kg in kg_list:
            for node in kg.nodes:
                node_id_str = str(node.id)
                if node_id_str in existing_node_ids:
                    continue
                new_nodes.append(deepcopy(node))
                existing_node_ids.add(node_id_str)

        valid_node_ids = {str(n.id) for n in new_nodes}
        for kg in kg_list:
            for edge in kg.edges:
                if edge.source in valid_node_ids and edge.target in valid_node_ids:
                    new_edges.append(deepcopy(edge))

        return KG(nodes=new_nodes, edges=new_edges)


async def main():
    kg_operator = KGOperator()
    node1 = await kg_operator.create_node("Person", "Alice", {"age": "30"})
    node2 = await kg_operator.create_node("Person", "Bob", {"age": "25"})
    edge = await kg_operator.create_edge(str(node1.id), str(node2.id), "knows", "Alice knows Bob")

    json_output = await kg_operator.to_json()
    print(json_output)


async def test_merge_kg_list():
    # Initialize main KGOperator
    op = KGOperator()

    # Add initial nodes and edges
    node1 = await op.create_node("Person", "Alice", {"age": "30"})
    node2 = await op.create_node("Person", "Bob", {"age": "25"})
    await op.create_edge(str(node1.id), str(node2.id), "knows", "Alice knows Bob")

    # Prepare other KGs, including duplicate nodes
    node3 = Node(id=node1.id, type="Person", name="Alice", attributes={"age": "35"})  # duplicate ID
    node4 = Node(id=uuid4(), type="Person", name="Charlie", attributes={"age": "20"})  # new node
    edge1 = Edge(source=str(node3.id), target=str(node4.id), type="knows", name="Alice knows Charlie")

    node5 = Node(id=uuid4(), type="Place", name="CityA", attributes={})
    edge2 = Edge(source=str(node4.id), target=str(node5.id), type="lives_in", name="Charlie lives in CityA")

    other_kg1 = KG(nodes=[node3, node4], edges=[edge1])
    other_kg2 = KG(nodes=[node5], edges=[edge2])

    # Merge other KGs
    await op.merge_kg_list([other_kg1, other_kg2])

    # Output merged KG
    merged_kg_json = await op.to_json()
    with open("unvalidated_kg.json", 'w', encoding='utf-8') as f:
        f.write(merged_kg_json)


if __name__ == "__main__":
    with open("../../input/test_kg.json", 'r', encoding='utf-8') as f:
        data = f.read()
    kg_operator = asyncio.run(KGOperator.from_json(data))
    triples = asyncio.run(kg_operator.find_triple_by_one_node_and_one_edge(
        node_name="kung fu film",
        edge_name="Creates"
    ))
    for triple in triples:
        source_entity = asyncio.run(kg_operator.find_node_by_id(triple.source))
        target_entity = asyncio.run(kg_operator.find_node_by_id(triple.target))
        print(f"({source_entity.name}, {triple.name}, {target_entity.name}) relationtype: {triple.type}")
