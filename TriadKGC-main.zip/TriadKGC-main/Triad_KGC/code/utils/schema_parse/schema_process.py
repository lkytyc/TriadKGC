import random

from Triad_KGC.code.types.models import Node, Edge, KG
import json
from Triad_KGC.code.types.kg_operator import KGOperator

import os
from typing import Dict, Set, Tuple

# Get project root directory
current_path = os.path.abspath(__file__)
current_dir = os.path.dirname(current_path)
parent_dir = os.path.dirname(current_dir)
root_dir = os.path.dirname(parent_dir)
INPUT_DIR = os.path.join(root_dir, 'input')


async def transfer2schema_kg(kg, type_definition) -> KG:
    """
    Convert a KG to a schema KG:
    1. Deduplicate nodes based on entity types;
    2. Deduplicate edges based on (src_type, rel_type, tgt_type);
    3. Node IDs use the ID of the first encountered instance node of that type;
       Edge IDs are randomly generated.
    """
    op = KGOperator(kg=kg)
    seen_node_types: Dict[str, str] = {}
    schema_nodes: list[Node] = []
    seen_edge_keys: Set[Tuple[str, str, str]] = set()
    schema_edges: list[Edge] = []

    type_definition = {k.lower(): v for k, v in type_definition.items()}

    # 1. Collect type triples from all edges and generate schema_nodes
    for data in kg.edges:
        src_node = await op.find_node_by_id(data.source)
        tgt_node = await op.find_node_by_id(data.target)
        if not src_node or not tgt_node:
            continue
        src_type = src_node.type
        tgt_type = tgt_node.type

        # Deduplicate nodes
        if src_type not in seen_node_types:
            seen_node_types[src_type] = data.source
            schema_nodes.append(Node(
                id=data.source,
                name=src_type,
                type="type",
                attributes={"definition": type_definition.get(src_type.lower(), "")}
            ))
        if tgt_type not in seen_node_types:
            seen_node_types[tgt_type] = data.target
            schema_nodes.append(Node(
                id=data.target,
                name=tgt_type,
                type="type",
                attributes={"definition": type_definition.get(tgt_type.lower(), "")}
            ))

    # 2. Collect schema_edges, deduplicate by type triples
    for data in kg.edges:
        src_node = await op.find_node_by_id(data.source)
        tgt_node = await op.find_node_by_id(data.target)
        if not src_node or not tgt_node:
            continue
        src_type = src_node.type
        tgt_type = tgt_node.type
        rel_type = data.type

        key = (src_type, rel_type, tgt_type)
        if key in seen_edge_keys:
            continue
        seen_edge_keys.add(key)

        schema_edges.append(Edge(
            source=seen_node_types[src_type],
            target=seen_node_types[tgt_type],
            type='type',
            name=data.type,
            attributes={"definition": type_definition.get(data.type.lower(), "")}
        ))

    return KG(nodes=schema_nodes, edges=schema_edges)


async def annotate_edge_user_add(schema: dict, seed: int = None):
    """
    Randomly annotate each edge in the schema with either source_user_add or target_user_add.

    Args:
      - schema: A dict containing "nodes" and "edges".
      - seed: Optional random seed for reproducibility.

    Returns:
      - Modified schema with user-added annotations in edge["attributes"].
    """
    if seed is not None:
        random.seed(seed)

    for edge in schema.get("edges", []):
        # Ensure attributes exist
        attrs = edge.setdefault("attributes", {})

        # Randomly mark one endpoint
        if random.choice([True, False]):
            attrs["source_user_add"] = "true"
        else:
            attrs["target_user_add"] = "true"

    return json.dumps(schema)


async def find_instance_by_type_triple(kg_operator, type_triple):
    source_type_entity = type_triple.source_entity
    target_type_entity = type_triple.target_entity
    edge_type = type_triple.edge
    instance_triples = []
    source_instances = await kg_operator.find_nodes_by_type(type_=source_type_entity.name)
    for source_node in source_instances:
        edges = await kg_operator.find_edges_by_source(source_id=source_node.id)
        for edge in edges:
            if edge.type == edge_type.name:
                target_node = await kg_operator.find_node_by_id(node_id=edge.target)
                if target_node.type == target_type_entity.name:
                    instance_triple = {
                        "source_node": source_node.name,
                        "source_node_description": source_node.attributes['desc'],
                        "edge": edge.name,
                        "target_node": target_node.name,
                        "target_node_description": target_node.attributes['desc'],
                    }
                    instance_triples.append(instance_triple)
    if instance_triples:
        return instance_triples
    return []


async def process_kg(kg_data, type_definition, entity_description):
    """Core asynchronous logic for processing the knowledge graph"""
    kg_op = await KGOperator.from_dict(kg_data)
    e_desc_dict = {}
    for e_information in entity_description:
        e_desc_dict[e_information["entity"]] = e_information["entity_desc"]
    for entity in kg_op.kg.nodes:
        entity.attributes['desc'] = e_desc_dict.get(entity.name)
    kg_json = await kg_op.to_json()
    schema_kg = await transfer2schema_kg(kg_op.kg, type_definition)
    schema_op = KGOperator(kg=schema_kg)
    schema_json = await schema_op.to_json()

    return kg_json, schema_json


async def schema_process(kg_data: dict, type_definition: dict, entity_description: dict):
    # Execute asynchronous processing and save results
    kg_json, schema_json = await process_kg(kg_data=kg_data,
                                            type_definition=type_definition,
                                            entity_description=entity_description)
    user_add_schema_json = await annotate_edge_user_add(json.loads(schema_json))

    return kg_json, user_add_schema_json
